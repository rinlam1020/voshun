# Header #1


Đây là một gói giao diện mục **HEADER** được đóng gói theo Toàn Năng Component Plugin
![alt text](https://raw.githubusercontent.com/lamdeptrai/header/master/screenshoot.jpg)

## Bắt đầu

Tải gói này về, đặt vào thư mục
```
  wp-content/plugins/toannang-component/components/
```



## Yêu cầu bắt buộc
Bạn phải cài đặt trước các gói Plugin bắt buộc trước khi kích hoạt tính năng này
```
Toàn Năng Components Plugin
Gravity Form v4.0 or higher
Advanced Custom Field Pro 5.7 or higher
```
Tiếp đó, import dữ liệu sẵn trong Project
```
/acf-export-2018-07-08.json
/gravityforms-export-2018-07-08.json
```
Ngoài ra, bạn phải cài thêm menu trong mục Giao diện > Menu, tên menu bắt buộc là **Main Menu**

## Tác giả

* **Lam Phan** - *Toàn Năng Header Component* - [LamPhan](https://github.com/lamdeptrai)



## Chứng nhận

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details
